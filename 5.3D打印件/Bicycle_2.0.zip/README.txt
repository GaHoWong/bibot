                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1935871
Bicycle 2.0 by brian_strickler is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Bicycle 2.0. A cleaner looking design compared to my first bicycle. Hardware for this build includes Steel Socket Cap Screws M3-0.5 cut to various lengths. Print everything in ABS/PLA except the tires which can be printed in a flexible material such as TPE (Ninjaflex). 
Follow me on Instagram:
https://www.instagram.com/brian3dprints

Purchase filament used in this 3D print!

Red ABS
<a target="_blank"  href="https://www.amazon.com/gp/product/B00J0HB1YI/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=B00J0HB1YI&linkCode=as2&tag=brian3dprints-20&linkId=1f91d2bec5469e56974e563f45970301"><img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&MarketPlace=US&ASIN=B00J0HB1YI&ServiceVersion=20070822&ID=AsinImage&WS=1&Format=_SL250_&tag=brian3dprints-20" ></a><img src="//ir-na.amazon-adsystem.com/e/ir?t=brian3dprints-20&l=am2&o=1&a=B00J0HB1YI" width=".75" height=".75" border="0" alt="" style="border:none !important; margin:0px !important;" />
Grey PLA
<a target="_blank"  href="https://www.amazon.com/gp/product/B015I1CYFE/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=B015I1CYFE&linkCode=as2&tag=brian3dprints-20&linkId=9d1a4c6f59cc304641103191c238f87d"><img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&MarketPlace=US&ASIN=B015I1CYFE&ServiceVersion=20070822&ID=AsinImage&WS=1&Format=_SL250_&tag=brian3dprints-20" ></a><img src="//ir-na.amazon-adsystem.com/e/ir?t=brian3dprints-20&l=am2&o=1&a=B015I1CYFE" width=".75" height=".75" border="0" alt="" style="border:none !important; margin:0px !important;" />
Black ABS
<a target="_blank"  href="https://www.amazon.com/gp/product/B00J0H8EWA/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=B00J0H8EWA&linkCode=as2&tag=brian3dprints-20&linkId=ca520f9c21d002648edeb0d4fde26cda"><img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&MarketPlace=US&ASIN=B00J0H8EWA&ServiceVersion=20070822&ID=AsinImage&WS=1&Format=_SL250_&tag=brian3dprints-20" ></a><img src="//ir-na.amazon-adsystem.com/e/ir?t=brian3dprints-20&l=am2&o=1&a=B00J0H8EWA" width=".75" height=".75" border="0" alt="" style="border:none !important; margin:0px !important;" />
<iframe src="//rcm-na.amazon-adsystem.com/e/cm?o=1&p=12&l=ur1&category=amazonvideosubs&banner=11XR3BAGVDW8V1CS1SR2&f=ifr&lc=pf4&linkID=147e88161f62c53cef1660014e6c3a2c&t=brian3dprints-20&tracking_id=brian3dprints-20" width="300" height="250" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>